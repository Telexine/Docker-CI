var express = require('express');
var server = express();
 

 
 
server.get('/', function(req, res) {  	
    res.end('Hello word!');
});
 
server.get('*', function(req, res) {
  	res.send('Not Found!', 404);
});
 
server.use(function(err, req, res, next) {  	
  	res.send(500, 'Something broke!');
    console.error(err.stack);
});
 
var port = process.argv[2] || '5000';
 
server.listen(port);
console.log('Listening on port ' + port);