console.log("Test1... ");
console.log("Test2... ");
console.log("Test3... ");
console.log("Test4... ");
console.log("Test1... ");
setTimeout(function(){ console.log("Test 5 sec... "); }, 5000);
